unsigned levenshtein(const char *, const char *);
